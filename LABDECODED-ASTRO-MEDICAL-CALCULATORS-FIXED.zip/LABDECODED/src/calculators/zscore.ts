import type { CalculatorDefinition } from "../types/calculator";
const num=(v:string)=>Number(v);
const fixed=(v:number,n=2)=>Number.isFinite(v)?Number(v.toFixed(n)):0;

const calculator: CalculatorDefinition = {
  slug: 'zscore',
  title: 'Z-Score Calculator',
  description: 'Calculate a z-score from an observation, mean and SD.',
  category: 'Statistics',
  keywords: ['z score', 'statistics'],
  featured: false,
  inputs: [
  {
    "id": "x",
    "label": "Observed value",
    "type": "number",
    "unit": "",
    "required": true,
    "min": -1000000000.0,
    "max": 1000000000.0,
    "step": 0.01
  },
  {
    "id": "mean",
    "label": "Mean",
    "type": "number",
    "unit": "",
    "required": true,
    "min": -1000000000.0,
    "max": 1000000000.0,
    "step": 0.01
  },
  {
    "id": "sd",
    "label": "Standard deviation",
    "type": "number",
    "unit": "",
    "required": true,
    "min": 1e-06,
    "max": 1000000000.0,
    "step": 0.01
  }
],
  calculate(values) {
    const z=(num(values.x)-num(values.mean))/num(values.sd); return {primary:{label:"Z-score",value:fixed(z,3)}};
  },
  formula: 'z = (x − mean) / SD',
  references: [
  {
    "title": "LabDecoded calculator reference \u2014 verify against current clinical guidance."
  }
]
};
export default calculator;
