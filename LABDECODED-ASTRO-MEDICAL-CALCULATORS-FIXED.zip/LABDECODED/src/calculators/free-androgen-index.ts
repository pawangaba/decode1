import type { CalculatorDefinition } from "../types/calculator";
const num=(v:string)=>Number(v);
const fixed=(v:number,n=2)=>Number.isFinite(v)?Number(v.toFixed(n)):0;

const calculator: CalculatorDefinition = {
  slug: 'free-androgen-index',
  title: 'Free Androgen Index',
  description: 'Calculate the free androgen index from total testosterone and SHBG.',
  category: 'Endocrinology',
  keywords: ['free androgen index', 'fai'],
  featured: false,
  inputs: [
  {
    "id": "testosterone",
    "label": "Total testosterone",
    "type": "number",
    "unit": "nmol/L",
    "required": true,
    "min": 0.1,
    "max": 100,
    "step": 0.01
  },
  {
    "id": "shbg",
    "label": "SHBG",
    "type": "number",
    "unit": "nmol/L",
    "required": true,
    "min": 0.1,
    "max": 500,
    "step": 0.01
  }
],
  calculate(values) {
    const r=100*num(values.testosterone)/num(values.shbg); return {primary:{label:"Free Androgen Index",value:fixed(r,2),unit:"%"}};
  },
  formula: 'FAI (%) = total testosterone / SHBG × 100',
  references: [
  {
    "title": "LabDecoded calculator reference \u2014 verify against current clinical guidance."
  }
]
};
export default calculator;
